﻿<?php
/**
	Plugin Name: درگاه پرداخت جهان پی برای افزونه اشتراک طلایی
	Version: 1.0
	Description: درگاه پرداخت <a href="http://www.jahanpay.me/" target="_blank"> جهان پی</a> برای افزونه اشتراک طلایی
	Plugin URI: http://www.jahanpay.me/
	Author: jahanpay.me
	Author URI: http://jahanpay.me/
	License: GPL 2
 **/

if (!defined('ABSPATH')) exit;
if( !defined( 'SAMAN_SESSION_COOKIE' ) ) define( 'SAMAN_SESSION_COOKIE', '_PCHELPER_session' );

if ( !class_exists( 'Recursive_ArrayAccess' ) ) {
	class Recursive_ArrayAccess implements ArrayAccess {
		protected $container = array();
		protected $dirty = false;
		protected function __construct( $data = array() ) {
			foreach ( $data as $key => $value ) {
				$this[ $key ] = $value;
			}
		}
		public function __clone() {
			foreach ( $this->container as $key => $value ) {
				if ( $value instanceof self ) {
					$this[ $key ] = clone $value;
				}
			}
		}
		public function toArray() {
			$data = $this->container;
			foreach ( $data as $key => $value ) {
				if ( $value instanceof self ) {
					$data[ $key ] = $value->toArray();
				}
			}
			return $data;
		}
		public function offsetExists( $offset ) {
			return isset( $this->container[ $offset ]) ;
		}
		public function offsetGet( $offset ) {
			return isset( $this->container[ $offset ] ) ? $this->container[ $offset ] : null;
		}
		public function offsetSet( $offset, $data ) {
			if ( is_array( $data ) ) {
				$data = new self( $data );
			}
			if ( $offset === null ) { 
				$this->container[] = $data;
			}
			else {
				$this->container[ $offset ] = $data;
			}
			$this->dirty = true;
		}
		public function offsetUnset( $offset ) {
			unset( $this->container[ $offset ] );
			$this->dirty = true;
		}
	}
}
if ( !class_exists( 'SAMAN_Session' ) ) {
	final class SAMAN_Session extends Recursive_ArrayAccess implements Iterator, Countable {
		protected $session_id;
		protected $expires;
		protected $exp_variant;
		private static $instance = false;
		public static function get_instance() {
			if ( !self::$instance ) {
				self::$instance = new self();
			}
			return self::$instance;
		}
		protected function __construct() {
			if ( isset( $_COOKIE[SAMAN_SESSION_COOKIE] ) ) {
				$cookie = stripslashes( $_COOKIE[SAMAN_SESSION_COOKIE] );
				$cookie_crumbs = explode( '||', $cookie );
				$this->session_id = $cookie_crumbs[0];
				$this->expires = $cookie_crumbs[1];
				$this->exp_variant = $cookie_crumbs[2];
				if ( time() > $this->exp_variant ) {
					$this->set_expiration();
					delete_option( "_PCHELPER_session_expires_{$this->session_id}" );
					add_option( "_PCHELPER_session_expires_{$this->session_id}", $this->expires, '', 'no' );
				}
			} 
			else {
				$this->session_id = $this->generate_id();
				$this->set_expiration();
			}
			$this->read_data();
			$this->set_cookie();
		}
		protected function set_expiration() {
			$this->exp_variant = time() + (int) apply_filters( 'PCHELPER_session_expiration_variant', 24 * 60 );
			$this->expires = time() + (int) apply_filters( 'PCHELPER_session_expiration', 30 * 60 );
		}
		protected function set_cookie(){
			if( !headers_sent() )
				setcookie(SAMAN_SESSION_COOKIE,$this->session_id.'||'.$this->expires.'||'.$this->exp_variant,$this->expires,COOKIEPATH,COOKIE_DOMAIN );
		}
		protected function generate_id() {
			require_once( ABSPATH . 'wp-includes/class-phpass.php');
			$hasher = new PasswordHash( 8, false );
			return md5( $hasher->get_random_bytes( 32 ) );
		}
		protected function read_data() {
			$this->container = get_option( "_PCHELPER_session_{$this->session_id}", array() );
			return $this->container;
		}
		public function write_data() {
			$option_key = "_PCHELPER_session_{$this->session_id}";
			if ( $this->dirty ) {
				if ( false === get_option( $option_key ) ) {
					add_option( "_PCHELPER_session_{$this->session_id}", $this->container, '', 'no' );
					add_option( "_PCHELPER_session_expires_{$this->session_id}", $this->expires, '', 'no' );
				} 
				else {
					delete_option( "_PCHELPER_session_{$this->session_id}" );
					add_option( "_PCHELPER_session_{$this->session_id}", $this->container, '', 'no' );
				}
			}
		}
		public function json_out() {
			return json_encode( $this->container );
		}
		public function json_in( $data ) {
			$array = json_decode( $data );
			if ( is_array( $array ) ) {
				$this->container = $array;
				return true;
			}
			return false;
		}
		public function regenerate_id( $delete_old = false ) {
			if ( $delete_old ) {
				delete_option( "_PCHELPER_session_{$this->session_id}" );
			}
			$this->session_id = $this->generate_id();
			$this->set_cookie();
		}
		public function session_started() {
			return !!self::$instance;
		}
		public function cache_expiration() {
			return $this->expires;
		}
		public function reset() {
			$this->container = array();
		}
		public function current() {
			return current( $this->container );
		}
		public function key() {
			return key( $this->container );
		}
		public function next() {
			next( $this->container );
		}
		public function rewind() {
			reset( $this->container );
		}
		public function valid() {
			return $this->offsetExists( $this->key() );
		}
		public function count() {
			return count( $this->container );
		}
	}
	function PCHELPER_session_cache_expire() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->cache_expiration();
	}
	function PCHELPER_session_commit() {
		PCHELPER_session_write_close();
	}
	function PCHELPER_session_decode( $data ) {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->json_in( $data );
	}
	function PCHELPER_session_encode() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		return $PCHELPER_session->json_out();
	}
	function PCHELPER_session_regenerate_id( $delete_old_session = false ) {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->regenerate_id( $delete_old_session );
		return true;
	}
	function PCHELPER_session_start() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		do_action( 'PCHELPER_session_start' );
		return $PCHELPER_session->session_started();
	}
	add_action( 'plugins_loaded', 'PCHELPER_session_start' );
	function PCHELPER_session_status() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		if ( $PCHELPER_session->session_started() ) {
			return PHP_SESSION_ACTIVE;
		}
		return PHP_SESSION_NONE;
	}
	function PCHELPER_session_unset() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->reset();
	}
	function PCHELPER_session_write_close() {
		$PCHELPER_session = SAMAN_Session::get_instance();
		$PCHELPER_session->write_data();
		do_action( 'PCHELPER_session_commit' );
	}
	add_action( 'shutdown', 'PCHELPER_session_write_close' );
	function PCHELPER_session_cleanup() {
		global $wpdb;
		if ( defined( 'SAMAN_SETUP_CONFIG' ) ) {
			return;
		}
		if ( ! defined( 'SAMAN_INSTALLING' ) ) {
			$expiration_keys = $wpdb->get_results( "SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE '_PCHELPER_session_expires_%'" );
			$now = time();
			$expired_sessions = array();
			foreach( $expiration_keys as $expiration ) {
				if ( $now > intval( $expiration->option_value ) ) {
					$session_id = substr( $expiration->option_name, 20 );
					$expired_sessions[] = $expiration->option_name;
					$expired_sessions[] = "_PCHELPER_session_$session_id";
				}
			}
			if ( ! empty( $expired_sessions ) ) {
				$option_names = implode( "','", $expired_sessions );
				$wpdb->query( "DELETE FROM $wpdb->options WHERE option_name IN ('$option_names')" );
			}
		}
		do_action( 'PCHELPER_session_cleanup' );
	}
	add_action( 'PCHELPER_session_garbage_collection', 'PCHELPER_session_cleanup' );
	function PCHELPER_session_register_garbage_collection() {
		if ( !wp_next_scheduled( 'PCHELPER_session_garbage_collection' ) ) {
			wp_schedule_event( time(), 'hourly', 'PCHELPER_session_garbage_collection' );
		}
	}
	add_action( 'wp', 'PCHELPER_session_register_garbage_collection' );
}

if (!class_exists('RCP_jahanpay') )
{
	class RCP_jahanpay
	{
		public function __construct()
		{
			add_action('init', array($this, 'jahanpay_Verify'));
			add_action('rcp_payments_settings', array($this, 'jahanpay_Setting'));
			add_action('rcp_gateway_jahanpay', array($this, 'jahanpay_Request'));
			add_filter('rcp_payment_gateways', array($this, 'jahanpay_Register'));
			if ( !function_exists('RCP_IRAN_Currencies_By_PCHELPER') && !function_exists('RCP_IRAN_Currencies') )
				add_filter('rcp_currencies', array($this, 'RCP_IRAN_Currencies'));
		}

		public function RCP_IRAN_Currencies( $currencies ) {
			unset($currencies['RIAL']);
			$currencies['ریال'] = __('ریال', 'rcp_jahanpay');
			return $currencies;
		}
				
		public function jahanpay_Register($gateways) {
			global $rcp_options;
			
			if( version_compare( RCP_PLUGIN_VERSION, '2.1.0', '<' ) ) {
				$gateways['jahanpay'] = isset($rcp_options['jahanpay_name']) ? $rcp_options['jahanpay_name'] : __( 'جهان پی', 'rcp_jahanpay');
			}
			else {
				$gateways['jahanpay'] = array(
					'label' => isset($rcp_options['jahanpay_name']) ? $rcp_options['jahanpay_name'] : __( 'جهان پی', 'rcp_jahanpay'),
					'admin_label' => isset($rcp_options['jahanpay_name']) ? $rcp_options['jahanpay_name'] : __( 'جهان پی', 'rcp_jahanpay'),
				);
			}
			return $gateways;
		}

		public function jahanpay_Setting($rcp_options) {
		echo '	
			<hr/>
			<table class="form-table">'; ?>
				<?php do_action( 'RCP_jahanpay_before_settings', $rcp_options ); ?>
				<?php echo '<tr valign="top">
					<th colspan=2><h3>'; ?> <?php _e( 'تنظیمات درگاه جهان پی', 'rcp_jahanpay' ); ?><?php echo '</h3></th>
				</tr>
				<tr valign="top">
					<th>
						<label for="rcp_settings[merchant]">'; ?><?php _e( 'مرچنت درگاه جهان پی', 'rcp_jahanpay' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[merchant]" style="width: 300px;" name="rcp_settings[merchant]" value="'; ?><?php if( isset( $rcp_options['merchant'] ) ) { echo $rcp_options['merchant']; } ?><?php echo '"/>
					</td>
				</tr>					
				<tr valign="top">
					<th>
						<label for="rcp_settings[jahanpay_query_name]">'; ?><?php _e( 'نام لاتین درگاه', 'rcp_jahanpay' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[jahanpay_query_name]" style="width: 300px;" name="rcp_settings[jahanpay_query_name]" value="'; ?><?php echo isset($rcp_options['jahanpay_query_name']) ? $rcp_options['jahanpay_query_name'] : 'jahanpay'; ?><?php echo '"/>
						<div class="description">'; ?><?php _e( 'این نام در هنگام بازگشت از بانک در آدرس بازگشت از بانک نمایان خواهد شد . از به کاربردن حروف زائد و فاصله جدا خودداری نمایید .', 'rcp_jahanpay' ); ?><?php echo '</div>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label for="rcp_settings[jahanpay_name]">'; ?><?php _e( 'نام نمایشی درگاه', 'rcp_jahanpay' ); ?><?php echo '</label>
					</th>
					<td>
						<input class="regular-text" id="rcp_settings[jahanpay_name]" style="width: 300px;" name="rcp_settings[jahanpay_name]" value="'; ?><?php echo isset($rcp_options['jahanpay_name']) ? $rcp_options['jahanpay_name'] : __( 'جهان پی', 'rcp_jahanpay'); ?><?php echo '"/>
					</td>
				</tr>
				<tr valign="top">
					<th>
						<label>'; ?><?php _e( 'تذکر ', 'rcp_jahanpay' ); ?><?php echo '</label>
					</th>
					<td>
						<div class="description">'; ?><?php _e( 'از سربرگ مربوط به ثبت نام در تنظیمات افزونه حتما یک برگه برای بازگشت از بانک انتخاب نمایید . ترجیحا نامک برگه را لاتین قرار دهید .<br/> نیازی به قرار دادن شورت کد خاصی در برگه نیست و میتواند برگه ی خالی باشد .', 'rcp_jahanpay' ); ?><?php echo '</div>
					</td>
				</tr>'; ?>
				<?php do_action( 'RCP_jahanpay_after_settings', $rcp_options ); ?>
			<?php echo '</table>';
		}
		
		public function jahanpay_Request($subscription_data) {
			
			global $rcp_options;
			ob_start();
			$query = isset($rcp_options['jahanpay_query_name']) ? $rcp_options['jahanpay_query_name'] : 'jahanpay';
			$amount = str_replace( ',', '', $subscription_data['price']);

			
			
			
			
			//Action For jahanpay or RCP Developers...
			do_action( 'RCP_Before_Sending_to_jahanpay', $subscription_data );	
		
			if ($rcp_options['currency'] == 'ریال' || $rcp_options['currency'] == 'IRR' || $rcp_options['currency'] == 'RIAL' || $rcp_options['currency'] == 'ریال ایران' || $rcp_options['currency'] == 'Iranian Rial (&#65020;)')
				$amount = $amount/10;
			
			//Start of jahanpay
			$Price = intval($amount);
         $ReturnPath = add_query_arg('gateway', $query, $subscription_data['return_url']);
			$ResNumber = $subscription_data['key'];
			$Paymenter = $subscription_data['user_name'];
			$Email = $subscription_data['user_email'];
			$Description = sprintf(__('خرید اشتراک %s برای کاربر %s', 'rcp_jahanpay'), $subscription_data['subscription_name'],$subscription_data['user_name']);
			$Mobile = '-';			
			//Filter For jahanpay or RCP Developers...
			$Description = apply_filters( 'RCP_jahanpay_Description', $Description, $subscription_data );
			$Mobile = apply_filters( 'RCP_Mobile', $Mobile, $subscription_data );

			$resnum = time();
			$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
			$res = $client->requestpayment($rcp_options['merchant'], $amount, $ReturnPath, $resnum);
			if ($res['result'] AND $res['result'])
			{
			$au=$res['au'];
			$jahanpay_payment_data = array(
				'user_id'             => $subscription_data['user_id'],
				'subscription_name'     => $subscription_data['subscription_name'],
				'subscription_key'	 => $subscription_data['key'],
				'amount'           => $amount,
				'order_id'           => $resnum,
				'au'           => $au,
			);			
			$PCHELPER_session = SAMAN_Session::get_instance();
			@session_start();
			$PCHELPER_session['jahanpay_payment_data'] = $jahanpay_payment_data;
			$_SESSION["jahanpay_payment_data"] = $jahanpay_payment_data;	
			
				 echo ('<div style="display:none;">'.$res['form'].'</div><script>document.forms["jahanpay"].submit();</script>');
			}
			else
			{
				wp_die( sprintf(__('متاسفانه پرداخت به دلیل خطای زیر امکان پذیر نمی باشد . <br/><b> %s </b>', 'rcp_jahanpay'), $res['result']) );
			}
			//End of jahanpay
				
			exit;
		}
		
		public function jahanpay_Verify() {
			
			if (!isset($_GET['gateway']))
				return;
			
			if ( !class_exists('RCP_Payments') )
				return;
			
			global $rcp_options, $wpdb, $rcp_payments_db_name;
			@session_start();
			$PCHELPER_session = SAMAN_Session::get_instance();
			if (isset($PCHELPER_session['jahanpay_payment_data']))
				$jahanpay_payment_data = $PCHELPER_session['jahanpay_payment_data'];
			else 
				$jahanpay_payment_data = isset($_SESSION["jahanpay_payment_data"]) ? $_SESSION["jahanpay_payment_data"] : '';
			
			$query = isset($rcp_options['jahanpay_query_name']) ? $rcp_options['jahanpay_query_name'] : 'jahanpay';
			
			if ($jahanpay_payment_data)
			{
				$user_id 			= $jahanpay_payment_data['user_id'];
				$subscription_name 	= $jahanpay_payment_data['subscription_name'];
				$subscription_key 	= $jahanpay_payment_data['subscription_key'];
				$amount 			= $jahanpay_payment_data['amount'];
				$au 			= $jahanpay_payment_data['au'];
				$order_id 			= $jahanpay_payment_data['order_id'];
				$subscription_id    = rcp_get_subscription_id( $user_id );
				$user_data          = get_userdata( $user_id );
				$payment_method =  isset($rcp_options['jahanpay_name']) ? $rcp_options['jahanpay_name'] : __( 'جهان پی', 'rcp_jahanpay');

				$member = new RCP_Member( $user_id );
				$subscription_id = $member->get_pending_subscription_id();
				if( empty( $subscription_id ) ) $subscription_id = $member->get_subscription_id();

				if( ! $user_data || ! $subscription_id || ! rcp_get_subscription_details( $subscription_id ) )
					return;
				$new_payment = 1;
				if( $wpdb->get_results( $wpdb->prepare("SELECT id FROM " . $rcp_payments_db_name . " WHERE `subscription_key`='%s' AND `payment_type`='%s';", $subscription_key, $payment_method ) ) )
					$new_payment = 0;

				unset($GLOBALS['jahanpay_new']);
				$GLOBALS['jahanpay_new'] = $new_payment;
				global $new;
				$new = $new_payment;
				if ($new_payment == 1)
				{
					$client = new SoapClient("http://www.jpws.me/directservice?wsdl");
                    $res = $client->verification($rcp_options['merchant'], $amount , $au , $order_id, $_POST + $_GET );
					if (!empty($res['result'])&&$res['result']==1)
					{
						$payment_status = 'completed';
						$fault = 'completed';
						$transaction_id = $au;
					}
					else
					{
						$payment_status = 'failed';
						$fault = 'eRR : '.$res;
						$transaction_id = 0;
					}
					unset($GLOBALS['jahanpay_payment_status']);
					unset($GLOBALS['jahanpay_transaction_id']);
					unset($GLOBALS['jahanpay_fault']);
					unset($GLOBALS['jahanpay_subscription_key']);
					$GLOBALS['jahanpay_payment_status'] = $payment_status;
					$GLOBALS['jahanpay_transaction_id'] = $transaction_id;
					$GLOBALS['jahanpay_subscription_key'] = $subscription_key;
					$GLOBALS['jahanpay_fault'] = $fault;
					global $jahanpay_transaction;
					$jahanpay_transaction = array();
					$jahanpay_transaction['jahanpay_payment_status'] = $payment_status;
					$jahanpay_transaction['jahanpay_transaction_id'] = $transaction_id;
					$jahanpay_transaction['jahanpay_subscription_key'] = $subscription_key;
					$jahanpay_transaction['jahanpay_fault'] = $fault;
					if ($payment_status == 'completed') 
					{
				
						$payment_data = array(
							'date'             => date('Y-m-d g:i:s'),
							'subscription'     => $subscription_name,
							'payment_type'     => $payment_method,
							'subscription_key' => $subscription_key,
							'amount'           => $amount,
							'user_id'          => $user_id,
							'transaction_id'   => $transaction_id
						);
					
						//Action For jahanpay or RCP Developers...
						do_action( 'RCP_jahanpay_Insert_Payment', $payment_data, $user_id );
					
						$rcp_payments = new RCP_Payments();
						$rcp_payments->insert( $payment_data );					
					
						rcp_set_status( $user_id, 'active' );
						
						if( version_compare( RCP_PLUGIN_VERSION, '2.1.0', '<' ) ) {
							rcp_email_subscription_status( $user_id, 'active' );
							if( ! isset( $rcp_options['disable_new_user_notices'] ) )
								wp_new_user_notification( $user_id );
						}
						
						
						update_user_meta( $user_id, 'rcp_payment_profile_id', $user_id );
						
						update_user_meta( $user_id, 'rcp_signup_method', 'live' );
						//rcp_recurring is just for paypal or ipn gateway
						update_user_meta( $user_id, 'rcp_recurring', 'no' ); 
					
						$subscription = rcp_get_subscription_details( rcp_get_subscription_id( $user_id ) );
						$member_new_expiration = date( 'Y-m-d H:i:s', strtotime( '+' . $subscription->duration . ' ' . $subscription->duration_unit . ' 23:59:59' ) );
						rcp_set_expiration_date( $user_id, $member_new_expiration );	
						delete_user_meta( $user_id, '_rcp_expired_email_sent' );
									
						$log_data = array(
							'post_title'    => __( 'تایید پرداخت', 'rcp_jahanpay' ),
							'post_content'  =>  __( 'پرداخت با موفقیت انجام شد . کد تراکنش : ', 'rcp_jahanpay' ).$transaction_id.__( ' .  روش پرداخت : ', 'rcp_jahanpay' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );

						//Action For jahanpay or RCP Developers...
						do_action( 'RCP_jahanpay_Completed', $user_id );				
					}	

					
					
					if ($payment_status == 'cancelled')
					{
					
						$log_data = array(
							'post_title'    => __( 'انصراف از پرداخت', 'rcp_jahanpay' ),
							'post_content'  =>  __( 'تراکنش به دلیل انصراف کاربر از پرداخت ، ناتمام باقی ماند .', 'rcp_jahanpay' ).__( ' روش پرداخت : ', 'rcp_jahanpay' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );
					
						//Action For jahanpay or RCP Developers...
						do_action( 'RCP_jahanpay_Cancelled', $user_id );	

					}	
					
					if ($payment_status == 'failed') 
					{
									
						$log_data = array(
							'post_title'    => __( 'خطا در پرداخت', 'rcp_jahanpay' ),
							'post_content'  =>  __( 'تراکنش به دلیل خطای رو به رو ناموفق باقی ماند :', 'rcp_jahanpay' ).$this->Fault_Get($fault).__( ' روش پرداخت : ', 'rcp_jahanpay' ).$payment_method,
							'post_parent'   => 0,
							'log_type'      => 'gateway_error'
						);

						$log_meta = array(
							'user_subscription' => $subscription_name,
							'user_id'           => $user_id
						);
						
						$log_entry = WP_Logging::insert_log( $log_data, $log_meta );
					
						//Action For jahanpay or RCP Developers...
						do_action( 'RCP_jahanpay_Failed', $user_id );	
					
					}
			
				}
				add_filter( 'the_content', array($this,  'jahanpay_Content_After_Return') );
			}
		}
		 
		
		public function jahanpay_Content_After_Return( $content ) { 
			
			global $jahanpay_transaction, $new;
			
			$PCHELPER_session = SAMAN_Session::get_instance();
			@session_start();
			
			$new_payment = isset($GLOBALS['jahanpay_new']) ? $GLOBALS['jahanpay_new'] : $new;
			
			$payment_status = isset($GLOBALS['jahanpay_payment_status']) ? $GLOBALS['jahanpay_payment_status'] : $jahanpay_transaction['jahanpay_payment_status'];
			$transaction_id = isset($GLOBALS['jahanpay_transaction_id']) ? $GLOBALS['jahanpay_transaction_id'] : $jahanpay_transaction['jahanpay_transaction_id'];
			$fault = isset($GLOBALS['jahanpay_fault']) ? $this->Fault_Get($GLOBALS['jahanpay_fault']) : $this->Fault_Get($jahanpay_transaction['jahanpay_fault']);
			
			if ($new_payment == 1) 
			{
			
				$jahanpay_data = array(
					'payment_status'             => $payment_status,
					'transaction_id'     => $transaction_id,
					'fault'     => $fault
				);
				
				$PCHELPER_session['jahanpay_data'] = $jahanpay_data;
				$_SESSION["jahanpay_data"] = $jahanpay_data;	
			
			}
			else
			{
				if (isset($PCHELPER_session['jahanpay_data']))
					$jahanpay_payment_data = $PCHELPER_session['jahanpay_data'];
				else 
					$jahanpay_payment_data = isset($_SESSION["jahanpay_data"]) ? $_SESSION["jahanpay_data"] : '';
			
				$payment_status = isset($jahanpay_payment_data['payment_status']) ? $jahanpay_payment_data['payment_status'] : '';
				$transaction_id = isset($jahanpay_payment_data['transaction_id']) ? $jahanpay_payment_data['transaction_id'] : '';
				$fault = isset($jahanpay_payment_data['fault']) ? $this->Fault($jahanpay_payment_data['fault']) : '';
			}
			
			$message = '';
			
			if ($payment_status == 'completed') {
				$message = '<br/>'.__( 'پرداخت با موفقیت انجام شد . کد تراکنش : ', 'rcp_jahanpay' ).$transaction_id.'<br/>';
			}
			
			if ($payment_status == 'cancelled') {
				$message = '<br/>'.__( 'تراکنش به دلیل انصراف شما نا تمام باقی ماند .', 'rcp_jahanpay' );
			}
			
			if ($payment_status == 'failed') {
				$message = '<br/>'.__( 'تراکنش به دلیل خطای زیر ناموفق باقی ماند :', 'rcp_jahanpay' ).'<br/>'.$fault.'<br/>';
			}
			
			return $content.$message;
		}
		
		private static function Fault_Send($error) {
			$message = " ";
			switch($error)
			{
				case "-1" :
					$message = "merchant ارسالی تعریف نشده است";
				break;
				case "-2" :
					$message = "مبلغ تراکنش کمتر از 1000 ریال است";
				break;
				case "-3" :
					$message = "مسیر برگشت وجود ندارد";
				break;
										
				case "-4" :
					$message = "درگاه تعریف نشده است";
				break;	
			}
			return $message;
		}
		private static function Fault_Get($error)
		{
			return $error;
		}
		
	}
}
new RCP_jahanpay();

if ( !function_exists('change_cancelled_to_pending_By_PCHELPER'))
{
	add_action( 'rcp_set_status', 'change_cancelled_to_pending_By_PCHELPER', 10, 2 );
	function change_cancelled_to_pending_By_PCHELPER( $status, $user_id )
	{
		if( 'cancelled' == $status )
			rcp_set_status( $user_id, 'expired' );
		return true;
	}
}

?>